export const LANDING = '/';
export const FORGOT = '/forgot';
export const CONTACT = '/contact';
export const WORKERSMAIN = '/workersmain';
export const SIGNUP = '/signup';
export const WELCOME = '/welcome';
export const ADMIN_REQUESTS = '/admin_requests';
export const ID5 = '/id=5';
export const COMPLETE_REQUEST = '/complete-request';
export const PAYMENT = '/payment';
export const ADDWORKER = '/addworker';
export const EDITWORKER = '/editworker';
export const VIEWWORKER = '/viewworker';
export const CREATE_REQUEST = '/create_request';
export const ABOUT ='/about'
export const CONFIRMATION ='/confirmation'
export const SERVICECHARGES = "/prices";
export const FEEDBACK = "/feedback";
export const PROCESSING_REQUEST = "/processing-request";
export const PROCESSING_REQUEST2 = "/processing-request2";
export const REJECTION = "/rejection";



